/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#EEF2FF',   // Lightest indigo
          100: '#E0E7FF',  // Very light indigo
          200: '#C7D2FE',  // Light indigo
          300: '#A5B4FC',  // Medium-light indigo
          400: '#818CF8',  // Medium indigo
          500: '#6366F1',  // Base indigo
          600: '#4F46E5',  // Medium-dark indigo
          700: '#4338CA',  // Dark indigo
          800: '#3730A3',  // Very dark indigo
          900: '#1E1B4B',  // Darkest indigo/navy
        }
      },
      fontFamily: {
        sans: [
          'Inter',
          'system-ui',
          '-apple-system',
          'BlinkMacSystemFont',
          'Segoe UI',
          'Roboto',
          'Helvetica Neue',
          'Arial',
          'sans-serif',
        ],
        mono: [
          'JetBrains Mono',
          'Menlo',
          'Monaco',
          'Consolas',
          'Liberation Mono',
          'Courier New',
          'monospace',
        ],
      },
      animation: {
        'spin-slow': 'spin 3s linear infinite',
      },
      typography: (theme) => ({
        DEFAULT: {
          css: {
            color: theme('colors.slate.800'),
            maxWidth: 'none',
            'code::before': {
              content: '""',
            },
            'code::after': {
              content: '""',
            },
          },
        },
        invert: {
          css: {
            color: theme('colors.slate.100'),
          },
        },
      }),
    },
  },
  plugins: [],
};