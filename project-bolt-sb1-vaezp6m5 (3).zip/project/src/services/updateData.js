import { fetchData } from './dataService.js';
import fs from 'node:fs/promises';
import path from 'node:path';

async function updateData() {
  try {
    // Fetch latest data
    const data = await fetchData({
      zipCode: '',
      priceRange: [100000, 1500000],
      crimeRate: [0, 3000],
      schoolRating: [1, 2, 3],
      lowIncomePercentage: [0, 100],
      showPredicted: false,
      sortBy: 'price'
    });

    // Save to data file
    const dataPath = path.join(process.cwd(), 'src', 'data', 'realEstate.json');
    await fs.writeFile(dataPath, JSON.stringify(data, null, 2));

    console.log('Data updated successfully');
  } catch (error) {
    console.error('Error updating data:', error);
    process.exit(1);
  }
}