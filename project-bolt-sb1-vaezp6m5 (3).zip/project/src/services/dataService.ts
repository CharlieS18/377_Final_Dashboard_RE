import { FilterParams, DataPoint } from '../types/filters';
import realEstateData from '../data/realEstate.json';

export async function fetchData(filters: FilterParams): Promise<DataPoint[]> {
  // Use the local JSON data
  const data = realEstateData.locations as DataPoint[];

  // Apply filters
  return data.filter(point => {
    if (filters.zipCode && !point.zipCode.includes(filters.zipCode)) return false;
    if (point.averageHousingCost2023 < filters.priceRange[0] || 
        point.averageHousingCost2023 > filters.priceRange[1]) return false;
    if (point.totalCrimes < filters.crimeRate[0] || 
        point.totalCrimes > filters.crimeRate[1]) return false;
    if (!filters.schoolRating.includes(point.overallRating)) return false;
    return true;
  }).sort((a, b) => {
    switch (filters.sortBy) {
      case 'price':
        return b.averageHousingCost2023 - a.averageHousingCost2023;
      case 'crime':
        return a.totalCrimes - b.totalCrimes;
      case 'school':
        return b.overallRating - a.overallRating;
      case 'error':
        return Math.abs(b.priceError) - Math.abs(a.priceError);
      default:
        return 0;
    }
  });
}