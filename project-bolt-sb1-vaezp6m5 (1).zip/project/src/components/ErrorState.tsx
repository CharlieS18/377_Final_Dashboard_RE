import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface ErrorStateProps {
  message: string;
}

const ErrorState: React.FC<ErrorStateProps> = ({ message }) => {
  const handleRetry = () => {
    window.location.reload();
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-900 px-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-8 max-w-md w-full">
        <div className="flex items-center justify-center text-red-500 mb-4">
          <AlertTriangle size={40} />
        </div>
        <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4 text-center">
          Error Loading Data
        </h2>
        <p className="text-gray-600 dark:text-gray-300 text-center mb-6">
          {message}
        </p>
        <div className="flex justify-center">
          <button
            onClick={handleRetry}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            <RefreshCw size={16} className="mr-2" />
            Retry
          </button>
        </div>
      </div>
    </div>
  );
};

export default ErrorState;