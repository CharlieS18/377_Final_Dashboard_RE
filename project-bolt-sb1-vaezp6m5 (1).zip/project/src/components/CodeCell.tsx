import React, { useState } from 'react';
import SyntaxHighlighter from 'react-syntax-highlighter';
import { atomOneDark, atomOneLight } from 'react-syntax-highlighter/dist/esm/styles/hljs';
import { parseCodeCell } from '../services/notebookService';
import { NotebookCell, NotebookOutput } from '../types/notebook';
import { ChevronDown, ChevronUp, Code } from 'lucide-react';

interface CodeCellProps {
  cell: NotebookCell;
}

const CodeCell: React.FC<CodeCellProps> = ({ cell }) => {
  const [expanded, setExpanded] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return document.documentElement.classList.contains('dark');
  });

  React.useEffect(() => {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.attributeName === 'class') {
          setIsDarkMode(document.documentElement.classList.contains('dark'));
        }
      });
    });

    observer.observe(document.documentElement, { attributes: true });

    return () => observer.disconnect();
  }, []);

  const codeContent = parseCodeCell(cell.source);

  const renderOutput = (output: NotebookOutput) => {
    if (output.output_type === 'execute_result' || output.output_type === 'display_data') {
      if (output.data && output.data['text/html']) {
        return (
          <div
            className="output-html mt-2 p-3 bg-gray-50 dark:bg-gray-900 rounded overflow-auto"
            dangerouslySetInnerHTML={{ __html: output.data['text/html'].join('') }}
          />
        );
      } else if (output.data && output.data['text/plain']) {
        return (
          <div className="output-text mt-2 p-3 bg-gray-50 dark:bg-gray-900 rounded overflow-auto font-mono text-sm">
            {output.data['text/plain'].join('')}
          </div>
        );
      }
    } else if (output.output_type === 'stream') {
      return (
        <div className="output-stream mt-2 p-3 bg-gray-50 dark:bg-gray-900 rounded overflow-auto font-mono text-sm">
          {output.text?.join('') || ''}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="code-cell mb-6 overflow-hidden">
      <div 
        className="flex items-center justify-between p-2 bg-gray-100 dark:bg-gray-700 rounded-t cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div className="flex items-center text-gray-700 dark:text-gray-300">
          <Code size={16} className="mr-2" />
          <span className="font-mono text-sm">Code Cell {cell.execution_count !== null ? `[${cell.execution_count}]` : ''}</span>
        </div>
        <div>
          {expanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
        </div>
      </div>
      
      {expanded && (
        <>
          <SyntaxHighlighter
            language="python"
            style={isDarkMode ? atomOneDark : atomOneLight}
            customStyle={{ margin: 0, borderRadius: '0' }}
          >
            {codeContent}
          </SyntaxHighlighter>
          
          {cell.outputs && cell.outputs.length > 0 && (
            <div className="cell-outputs p-3 border border-t-0 border-gray-200 dark:border-gray-700 rounded-b">
              {cell.outputs.map((output, index) => (
                <div key={index} className="output">
                  {renderOutput(output)}
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default CodeCell;