import React, { useState } from 'react';
import { Download, ZoomIn, ZoomOut } from 'lucide-react';

interface VisualizationDisplayProps {
  imageData: string;
  index: number;
}

const VisualizationDisplay: React.FC<VisualizationDisplayProps> = ({ imageData, index }) => {
  const [zoomed, setZoomed] = useState(false);
  
  // Base64 images from Jupyter notebook are already prefixed
  const imgSrc = imageData.startsWith('data:image') 
    ? imageData 
    : `data:image/png;base64,${imageData}`;
  
  const handleDownload = () => {
    const a = document.createElement('a');
    a.href = imgSrc;
    a.download = `visualization-${index + 1}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="visualization-container">
      <div className="flex justify-between items-center mb-3">
        <h3 className="text-lg font-medium text-gray-800 dark:text-white">
          Figure {index + 1}
        </h3>
        <div className="flex space-x-2">
          <button
            onClick={() => setZoomed(!zoomed)}
            className="p-1.5 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            title={zoomed ? "Zoom out" : "Zoom in"}
          >
            {zoomed ? <ZoomOut size={16} /> : <ZoomIn size={16} />}
          </button>
          <button
            onClick={handleDownload}
            className="p-1.5 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
            title="Download image"
          >
            <Download size={16} />
          </button>
        </div>
      </div>
      
      <div
        className={`visualization-image-container overflow-hidden rounded-lg ${
          zoomed ? 'fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 md:p-10' : ''
        }`}
        onClick={() => zoomed && setZoomed(false)}
      >
        <div 
          className={zoomed ? 'max-w-full max-h-full overflow-auto' : ''}
          onClick={(e) => zoomed && e.stopPropagation()}
        >
          <img
            src={imgSrc}
            alt={`Visualization ${index + 1}`}
            className={`max-w-full ${
              zoomed ? 'cursor-zoom-out' : 'cursor-zoom-in transition-transform hover:scale-[1.02]'
            }`}
            onClick={() => !zoomed && setZoomed(true)}
          />
        </div>
      </div>
    </div>
  );
};

export default VisualizationDisplay;