import React from 'react';

const LoadingState: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-900 px-4">
      <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 dark:border-blue-400 mb-4"></div>
      <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-2">Loading Notebook Data</h2>
      <p className="text-gray-600 dark:text-gray-300 text-center max-w-md">
        Fetching and processing data from the Jupyter notebook. This may take a moment...
      </p>
    </div>
  );
};

export default LoadingState;