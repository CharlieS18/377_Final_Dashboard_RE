import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
import { FilterParams, DataPoint } from '../types/filters';
import FilterPanel from './FilterPanel';
import { fetchData } from '../services/dataService';
import LoadingState from './LoadingState';
import ErrorState from './ErrorState';
import { Map, BarChart, LineChart, PieChart, Users } from 'lucide-react';
import PriceDistribution from './visualizations/PriceDistribution';
import TimeSeries from './visualizations/TimeSeries';
import Demographics from './visualizations/Demographics';
import AboutPage from './AboutPage';
import 'leaflet/dist/leaflet.css';

const Dashboard: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<DataPoint[]>([]);
  const [activeTab, setActiveTab] = useState(0);
  
  const [filters, setFilters] = useState<FilterParams>({
    zipCode: '',
    priceRange: [100000, 1500000],
    crimeRate: [0, 3000],
    schoolRating: [1, 2, 3],
    lowIncomePercentage: [0, 100],
    showPredicted: false,
    sortBy: 'price'
  });

  const chicagoCenter: [number, number] = [41.8781, -87.6298];

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const result = await fetchData(filters);
        setData(result);
        setLoading(false);
      } catch (err) {
        setError('Failed to load data');
        setLoading(false);
      }
    };

    loadData();
  }, [filters]);

  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} />;

  const tabs = [
    { name: 'Map View', icon: Map },
    { name: 'Price Distribution', icon: BarChart },
    { name: 'Time Series', icon: LineChart },
    { name: 'Demographics', icon: PieChart },
    { name: 'About', icon: Users },
  ];

  const getMarkerColor = (price: number): string => {
    const [min, max] = filters.priceRange;
    const ratio = (price - min) / (max - min);
    if (ratio < 0.33) return '#22c55e';
    if (ratio < 0.66) return '#eab308';
    return '#ef4444';
  };

  return (
    <main className="container mx-auto px-4 py-6">
      <FilterPanel filters={filters} onChange={setFilters} />

      <section className="mb-8">
        <div className="border-b border-slate-200 dark:border-slate-700 mb-6">
          <nav className="flex space-x-4" aria-label="Tabs">
            {tabs.map((tab, index) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.name}
                  onClick={() => setActiveTab(index)}
                  className={`
                    flex items-center px-4 py-2 text-sm font-medium rounded-t-lg
                    ${activeTab === index
                      ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 border-b-2 border-primary-600'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300'}
                  `}
                >
                  <Icon size={18} className="mr-2" />
                  {tab.name}
                </button>
              );
            })}
          </nav>
        </div>

        {activeTab === 0 ? (
          <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-6 h-[600px]">
            <MapContainer
              center={chicagoCenter}
              zoom={11}
              style={{ height: '100%', width: '100%' }}
              className="rounded-lg"
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
              {data.map((point) => (
                <CircleMarker
                  key={point.zipCode}
                  center={[point.lat, point.lon]}
                  radius={10}
                  fillColor={getMarkerColor(point.averageHousingCost2023)}
                  color={getMarkerColor(point.averageHousingCost2023)}
                  weight={1}
                  opacity={0.8}
                  fillOpacity={0.6}
                >
                  <Popup>
                    <div className="p-2">
                      <h3 className="font-semibold text-primary-600">ZIP: {point.zipCode}</h3>
                      <p className="text-sm text-slate-600">
                        Avg. Price: ${point.averageHousingCost2023.toLocaleString()}
                      </p>
                      <p className="text-sm text-slate-600">
                        Crime Rate: {point.crimesPer1000Homes.toFixed(1)} per 1000
                      </p>
                      <p className="text-sm text-slate-600">
                        School Rating: {point.overallRating}
                      </p>
                    </div>
                  </Popup>
                </CircleMarker>
              ))}
            </MapContainer>
          </div>
        ) : activeTab === 1 ? (
          <PriceDistribution data={{
            labels: ['0-250k', '250k-500k', '500k-750k', '750k-1M', '1M+'],
            values: [15, 30, 25, 20, 10],
          }} />
        ) : activeTab === 2 ? (
          <TimeSeries data={{
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            values: [500000, 520000, 515000, 535000, 540000, 550000],
          }} />
        ) : activeTab === 3 ? (
          <Demographics data={{
            incomeDistribution: {
              labels: ['Low', 'Medium', 'High'],
              values: [30, 45, 25],
            },
            ageDistribution: {
              labels: ['18-24', '25-34', '35-44', '45-54', '55+'],
              values: [15, 30, 25, 20, 10],
            },
          }} />
        ) : (
          <AboutPage />
        )}
      </section>
    </main>
  );
};

export default Dashboard;