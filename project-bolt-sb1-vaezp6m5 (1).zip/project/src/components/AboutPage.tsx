import React from 'react';
import { Github, Mail, Globe } from 'lucide-react';

const teamMembers = [
  {
    name: "Team Member 1",
    role: "Data Scientist",
    image: "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=300",
    github: "https://github.com/username1",
    email: "email1@example.com"
  },
  {
    name: "Team Member 2",
    role: "Full Stack Developer",
    image: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=300",
    github: "https://github.com/username2",
    email: "email2@example.com"
  }
];

const AboutPage: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <section className="mb-16">
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-6">About the Project</h2>
        <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-8">
          <p className="text-slate-600 dark:text-slate-300 mb-6">
            This dashboard provides comprehensive real estate analytics for Chicago neighborhoods. 
            Using data science and machine learning techniques, we analyze housing prices, 
            demographics, and market trends to help users make informed decisions about real estate investments.
          </p>
          
          <h3 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">Key Features</h3>
          <ul className="list-disc list-inside text-slate-600 dark:text-slate-300 mb-6">
            <li>Interactive map visualization of property prices</li>
            <li>Time series analysis of market trends</li>
            <li>Demographic insights by neighborhood</li>
            <li>Price prediction model based on multiple factors</li>
          </ul>

          <h3 className="text-xl font-semibold text-slate-800 dark:text-white mb-4">Technologies Used</h3>
          <ul className="list-disc list-inside text-slate-600 dark:text-slate-300">
            <li>React with TypeScript</li>
            <li>Python for data analysis</li>
            <li>Jupyter Notebooks</li>
            <li>Chart.js for visualizations</li>
          </ul>
        </div>
      </section>

      <section>
        <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-6">Our Team</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {teamMembers.map((member, index) => (
            <div key={index} className="bg-white dark:bg-slate-800 rounded-lg shadow-lg overflow-hidden">
              <img 
                src={member.image} 
                alt={member.name} 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2">
                  {member.name}
                </h3>
                <p className="text-primary-600 dark:text-primary-400 mb-4">{member.role}</p>
                <div className="flex space-x-4">
                  <a 
                    href={member.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-slate-600 dark:text-slate-400 hover:text-primary-600 dark:hover:text-primary-400"
                  >
                    <Github size={20} />
                  </a>
                  <a 
                    href={`mailto:${member.email}`}
                    className="text-slate-600 dark:text-slate-400 hover:text-primary-600 dark:hover:text-primary-400"
                  >
                    <Mail size={20} />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default AboutPage;