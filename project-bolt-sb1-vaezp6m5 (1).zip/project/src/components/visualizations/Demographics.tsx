import React from 'react';
import { Pie, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  ArcElement,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(
  ArcElement,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface DemographicsProps {
  data: {
    incomeDistribution: {
      labels: string[];
      values: number[];
    };
    ageDistribution: {
      labels: string[];
      values: number[];
    };
  };
}

const Demographics: React.FC<DemographicsProps> = ({ data }) => {
  const pieData = {
    labels: data.incomeDistribution.labels,
    datasets: [
      {
        data: data.incomeDistribution.values,
        backgroundColor: [
          'rgba(14, 165, 233, 0.7)',
          'rgba(56, 189, 248, 0.7)',
          'rgba(186, 230, 253, 0.7)',
        ],
        borderColor: [
          'rgb(14, 165, 233)',
          'rgb(56, 189, 248)',
          'rgb(186, 230, 253)',
        ],
        borderWidth: 1,
      },
    ],
  };

  const barData = {
    labels: data.ageDistribution.labels,
    datasets: [
      {
        label: 'Population',
        data: data.ageDistribution.values,
        backgroundColor: 'rgba(14, 165, 233, 0.5)',
        borderColor: 'rgb(14, 165, 233)',
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4 text-slate-900 dark:text-white">
          Income Distribution
        </h3>
        <Pie data={pieData} />
      </div>
      <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-6">
        <h3 className="text-lg font-semibold mb-4 text-slate-900 dark:text-white">
          Age Distribution
        </h3>
        <Bar data={barData} />
      </div>
    </div>
  );
};

export default Demographics;