import React from 'react';
import { FilterParams } from '../types/filters';
import { Sliders, Search, School, AlertTriangle, DollarSign } from 'lucide-react';

interface FilterPanelProps {
  filters: FilterParams;
  onChange: (filters: FilterParams) => void;
}

const FilterPanel: React.FC<FilterPanelProps> = ({ filters, onChange }) => {
  const handleChange = (key: keyof FilterParams, value: any) => {
    onChange({ ...filters, [key]: value });
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-lg shadow-lg p-6 mb-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* ZIP Code Search */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-primary-600 dark:text-primary-400">
            ZIP Code
          </label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              placeholder="Enter ZIP code..."
              value={filters.zipCode}
              onChange={(e) => handleChange('zipCode', e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 dark:border-slate-600 
                       bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100"
            />
          </div>
        </div>

        {/* Price Range */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-primary-600 dark:text-primary-400 flex items-center">
            <DollarSign size={16} className="mr-1" />
            Price Range
          </label>
          <div className="flex items-center space-x-4">
            <input
              type="range"
              min="100000"
              max="1500000"
              step="10000"
              value={filters.priceRange[1]}
              onChange={(e) => handleChange('priceRange', [filters.priceRange[0], Number(e.target.value)])}
              className="w-full"
            />
            <span className="text-sm text-slate-600 dark:text-slate-400">
              ${filters.priceRange[1].toLocaleString()}
            </span>
          </div>
        </div>

        {/* Crime Rate */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-primary-600 dark:text-primary-400 flex items-center">
            <AlertTriangle size={16} className="mr-1" />
            Crime Rate
          </label>
          <div className="flex items-center space-x-4">
            <input
              type="range"
              min="0"
              max="3000"
              step="100"
              value={filters.crimeRate[1]}
              onChange={(e) => handleChange('crimeRate', [filters.crimeRate[0], Number(e.target.value)])}
              className="w-full"
            />
            <span className="text-sm text-slate-600 dark:text-slate-400">
              {filters.crimeRate[1]}
            </span>
          </div>
        </div>

        {/* School Rating */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-primary-600 dark:text-primary-400 flex items-center">
            <School size={16} className="mr-1" />
            School Rating
          </label>
          <div className="flex items-center space-x-4">
            {[1, 2, 3].map((rating) => (
              <label key={rating} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={filters.schoolRating.includes(rating)}
                  onChange={(e) => {
                    const newRatings = e.target.checked
                      ? [...filters.schoolRating, rating]
                      : filters.schoolRating.filter(r => r !== rating);
                    handleChange('schoolRating', newRatings);
                  }}
                  className="rounded border-slate-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="text-sm text-slate-600 dark:text-slate-400">{rating}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Advanced Options */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-primary-600 dark:text-primary-400 flex items-center">
            <Sliders size={16} className="mr-1" />
            Advanced
          </label>
          <div className="flex items-center space-x-4">
            <label className="flex items-center space-x-2">
              <input
                type="checkbox"
                checked={filters.showPredicted}
                onChange={(e) => handleChange('showPredicted', e.target.checked)}
                className="rounded border-slate-300 text-primary-600 focus:ring-primary-500"
              />
              <span className="text-sm text-slate-600 dark:text-slate-400">Show predicted prices</span>
            </label>
          </div>
        </div>

        {/* Sort By */}
        <div className="space-y-2">
          <label className="block text-sm font-medium text-primary-600 dark:text-primary-400">
            Sort By
          </label>
          <select
            value={filters.sortBy}
            onChange={(e) => handleChange('sortBy', e.target.value)}
            className="w-full p-2 rounded-lg border border-slate-200 dark:border-slate-600 
                     bg-slate-50 dark:bg-slate-700 text-slate-900 dark:text-slate-100"
          >
            <option value="price">Price</option>
            <option value="crime">Crime Rate</option>
            <option value="school">School Rating</option>
            <option value="error">Price Error</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default FilterPanel;