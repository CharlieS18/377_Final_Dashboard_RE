import React from 'react';
import ReactMarkdown from 'react-markdown';
import { NotebookCell } from '../types/notebook';
import { parseMarkdownCell } from '../services/notebookService';

interface MarkdownCellProps {
  cell: NotebookCell;
}

const MarkdownCell: React.FC<MarkdownCellProps> = ({ cell }) => {
  const markdownContent = parseMarkdownCell(cell.source);

  return (
    <div className="markdown-content prose dark:prose-invert max-w-none mb-6">
      <ReactMarkdown>{markdownContent}</ReactMarkdown>
    </div>
  );
};

export default MarkdownCell;