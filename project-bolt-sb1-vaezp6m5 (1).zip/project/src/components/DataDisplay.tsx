import React, { useState } from 'react';
import { NotebookCell } from '../types/notebook';

interface DataDisplayProps {
  cells: NotebookCell[];
}

const DataDisplay: React.FC<DataDisplayProps> = ({ cells }) => {
  const [activeTab, setActiveTab] = useState(0);

  // Find cells that likely contain data (e.g., DataFrame.head() outputs)
  const dataCells = cells.filter(cell => 
    cell.outputs && cell.outputs.some(output => 
      output.data && (output.data['text/html'] || output.data['text/plain'])
    )
  );

  if (dataCells.length === 0) {
    return (
      <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
        <p className="text-yellow-700 dark:text-yellow-200">
          No data tables found in the notebook.
        </p>
      </div>
    );
  }

  const renderDataTable = (cell: NotebookCell) => {
    if (!cell.outputs) return null;
    
    for (const output of cell.outputs) {
      if (output.data && output.data['text/html']) {
        return (
          <div 
            className="overflow-x-auto"
            dangerouslySetInnerHTML={{ __html: output.data['text/html'].join('') }} 
          />
        );
      } else if (output.data && output.data['text/plain']) {
        return (
          <pre className="overflow-x-auto p-4 bg-gray-50 dark:bg-gray-900 rounded font-mono text-sm">
            {output.data['text/plain'].join('')}
          </pre>
        );
      }
    }
    
    return null;
  };

  return (
    <div>
      {dataCells.length > 1 && (
        <div className="mb-4 border-b border-gray-200 dark:border-gray-700">
          <ul className="flex flex-wrap -mb-px">
            {dataCells.slice(0, 5).map((_, index) => (
              <li key={index} className="mr-2">
                <button
                  className={`inline-block py-2 px-4 text-sm font-medium ${
                    activeTab === index
                      ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600 dark:border-blue-400'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                  onClick={() => setActiveTab(index)}
                >
                  Data Table {index + 1}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="data-table-container animate-fadeIn">
        {renderDataTable(dataCells[activeTab])}
      </div>
    </div>
  );
};

export default DataDisplay;