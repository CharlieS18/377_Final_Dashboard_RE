import { FilterParams, DataPoint } from '../types/filters';

// Mock data service - replace with actual API calls
export async function fetchData(filters: FilterParams): Promise<DataPoint[]> {
  // Simulated API delay
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mock data
  const mockData: DataPoint[] = [
    {
      zipCode: '60601',
      averageHousingCost2023: 850000,
      totalCrimes: 1200,
      lowIncomePercentage: 15,
      overallRating: 2,
      ratingStatus: 'Medium',
      schoolLatitude: 41.8819,
      schoolLongitude: -87.6278,
      predictedPrice: 875000,
      priceError: -25000,
      crimesPer1000Homes: 45.2,
      schoolCount: 3,
      lat: 41.8819,
      lon: -87.6278
    },
    // Add more mock data points...
  ];

  // Apply filters
  return mockData.filter(point => {
    if (filters.zipCode && !point.zipCode.includes(filters.zipCode)) return false;
    if (point.averageHousingCost2023 < filters.priceRange[0] || 
        point.averageHousingCost2023 > filters.priceRange[1]) return false;
    if (point.totalCrimes < filters.crimeRate[0] || 
        point.totalCrimes > filters.crimeRate[1]) return false;
    if (!filters.schoolRating.includes(point.overallRating)) return false;
    return true;
  }).sort((a, b) => {
    switch (filters.sortBy) {
      case 'price':
        return b.averageHousingCost2023 - a.averageHousingCost2023;
      case 'crime':
        return a.totalCrimes - b.totalCrimes;
      case 'school':
        return b.overallRating - a.overallRating;
      case 'error':
        return Math.abs(b.priceError) - Math.abs(a.priceError);
      default:
        return 0;
    }
  });
}