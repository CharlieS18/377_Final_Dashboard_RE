import axios from 'axios';
import { Notebook } from '../types/notebook';

const GITHUB_RAW_URL = 'https://raw.githubusercontent.com';
const REPO_PATH = 'CharlieS18/377_Final_Dashboard_RE/main';

export interface FilterParams {
  month: string;
  type: string;
  search: string;
}

export async function fetchNotebook(): Promise<Notebook> {
  try {
    const response = await axios.get(
      `${GITHUB_RAW_URL}/${REPO_PATH}/.ipynb_checkpoints/project-checkpoint.ipynb`
    );
    return response.data as Notebook;
  } catch (error) {
    console.error('Failed to fetch notebook:', error);
    throw new Error('Failed to fetch notebook content');
  }
}

export function extractPlots(notebook: Notebook, filters: FilterParams): string[] {
  const plots: string[] = [];
  notebook.cells.forEach(cell => {
    if (cell.outputs) {
      cell.outputs.forEach(output => {
        if (output.data && output.data['image/png']) {
          // Apply filters based on cell metadata or content
          const matchesMonth = cell.metadata?.month === filters.month || !filters.month;
          const matchesType = cell.metadata?.type === filters.type || filters.type === 'All';
          const matchesSearch = !filters.search || 
            cell.source.some(line => line.toLowerCase().includes(filters.search.toLowerCase()));

          if (matchesMonth && matchesType && matchesSearch) {
            plots.push(output.data['image/png']);
          }
        }
      });
    }
  });
  return plots;
}

export interface ChicagoLocation {
  id: string;
  name: string;
  lat: number;
  lng: number;
  type: string;
  price: number;
}

export function getChicagoLocations(filters: FilterParams): ChicagoLocation[] {
  // This would normally fetch from an API - using mock data for demo
  return [
    { id: '1', name: 'Loop Property', lat: 41.8781, lng: -87.6298, type: 'Commercial', price: 1200000 },
    { id: '2', name: 'Lincoln Park Home', lat: 41.9250, lng: -87.6490, type: 'Residential', price: 750000 },
    { id: '3', name: 'Wicker Park Condo', lat: 41.9088, lng: -87.6796, type: 'Residential', price: 450000 },
  ].filter(location => 
    (filters.type === 'All' || location.type === filters.type) &&
    (!filters.search || location.name.toLowerCase().includes(filters.search.toLowerCase()))
  );
}