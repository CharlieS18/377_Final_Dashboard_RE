export interface FilterParams {
  zipCode: string;
  priceRange: [number, number];
  crimeRate: [number, number];
  schoolRating: number[];
  lowIncomePercentage: [number, number];
  showPredicted: boolean;
  sortBy: 'price' | 'crime' | 'school' | 'error';
}

export interface DataPoint {
  zipCode: string;
  averageHousingCost2023: number;
  totalCrimes: number;
  lowIncomePercentage: number;
  overallRating: number;
  ratingStatus: string;
  schoolLatitude: number;
  schoolLongitude: number;
  predictedPrice: number;
  priceError: number;
  crimesPer1000Homes: number;
  schoolCount: number;
  lat: number;
  lon: number;
}