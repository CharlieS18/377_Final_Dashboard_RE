export interface NotebookCell {
  cell_type: 'markdown' | 'code' | 'raw';
  metadata: Record<string, any>;
  source: string[];
  outputs?: NotebookOutput[];
  execution_count?: number | null;
}

export interface NotebookOutput {
  output_type: string;
  data?: {
    'text/plain'?: string[];
    'text/html'?: string[];
    'image/png'?: string;
    'application/json'?: any;
    [key: string]: any;
  };
  metadata?: Record<string, any>;
  execution_count?: number;
  text?: string[];
}

export interface Notebook {
  cells: NotebookCell[];
  metadata: {
    kernelspec: {
      display_name: string;
      language: string;
      name: string;
    };
    language_info: {
      name: string;
      version: string;
    };
    [key: string]: any;
  };
  nbformat: number;
  nbformat_minor: number;
}